#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdint.h>

#define MAX_MESSAGE_LENGTH 256

// Manually convert 16-bit integer to big-endian
uint16_t htobe16_manual(uint16_t value) {
    return (value << 8) | (value >> 8);
}

//Thread for receiving messages from the server
void *receiveThread(void *arg) {
    int clientSocket = *((int *)arg);
    char buffer[MAX_MESSAGE_LENGTH + 100];  // Extra space to handle buffer overflows
    int bytesReceived;
    int totalBytes = 0;  // Bytes in the buffer

    while (1) {
        // Receive data from server
        bytesReceived = recv(clientSocket, buffer + totalBytes, sizeof(buffer) - totalBytes - 1, 0);
        if (bytesReceived <= 0) {
            // Connection closed or error
            printf("Connection closed by the server.\n");
            exit(1);
        }
       
        totalBytes += bytesReceived;
        buffer[totalBytes] = '\0';  // Null-terminate the buffer

        // processing the buffer
        while (totalBytes > 4 && strncmp(buffer, "MESG", 4) == 0) {
            // Found a MESG prefix
            if (totalBytes < 8) {
                // not enough data for lengths yet
                break;
            }
          
            // Extract lenghts of username and message
            uint16_t username_length = be16toh(*(uint16_t *)(buffer + 4));
            uint16_t message_length = be16toh(*(uint16_t *)(buffer + 6 + username_length));

            // Check if complete message in buffer
            if (totalBytes < 8 + username_length + message_length) {
                // Message incomplete, wait for data
                break;
            }

            // Extract, print the message
            char username[21];
            strncpy(username, buffer + 6, username_length);
            username[username_length] = '\0';

            char message[MAX_MESSAGE_LENGTH + 1];
            strncpy(message, buffer + 8 + username_length, message_length);
            message[message_length] = '\0';

            printf("%s: %s\n", username, message);

            // Remove processed message from buffer
            memmove(buffer, buffer + 8 + username_length + message_length, totalBytes - (8 + username_length + message_length));
            totalBytes -= (8 + username_length + message_length);
        }
    }

    pthread_exit(NULL);
}

// Thread for clients
void *clientThread(void *arg) {
    int clientSocket = *((int *)arg);
    char username[20];  // Adjust username length 

    // Prompt the user to enter a username
    printf("Enter your username: ");
    fgets(username, sizeof(username), stdin);
    username[strlen(username) - 1] = '\0';  // Remove newline character

    // Send CNCT message with username to server
    uint16_t username_length = htobe16_manual(strlen(username));
    char cnct_msg[6 + strlen(username)];
    strcpy(cnct_msg, "CNCT");
    memcpy(cnct_msg + 4, &username_length, 2);
    strcpy(cnct_msg + 6, username);
    send(clientSocket, cnct_msg, sizeof(cnct_msg), 0);

    // wait for ackc message from server
    char ack_msg[4];
    recv(clientSocket, ack_msg, 4, 0);
    if (strncmp(ack_msg, "ACKC", 4) != 0) {
        printf("Failed to establish connection with the server.\n");
        close(clientSocket);
        exit(1);
    }

    // Create thread to receive messages
    pthread_t receive_tid;
    if (pthread_create(&receive_tid, NULL, receiveThread, &clientSocket) != 0) {
        perror("Thread creation for receiving failed");
        exit(1);
    }

    char message[MAX_MESSAGE_LENGTH];

    while (1) {
        // Read user input
        printf("Enter a message (or 'quit' to exit): ");
        fgets(message, sizeof(message), stdin);

        // if user wants to quit
        if (strncmp(message, "quit", 4) == 0) {
            // Send quit message to server
            send(clientSocket, "QUIT", 4, 0);
            break;
        }

        // Send the MESG message to the server
        uint16_t message_length = htobe16_manual(strlen(message) - 1);  // -1 exclude newline
        char mesg_msg[8 + strlen(username) + strlen(message)];
        strcpy(mesg_msg, "MESG");
        memcpy(mesg_msg + 4, &username_length, 2);
        strcpy(mesg_msg + 6, username);
        memcpy(mesg_msg + 6 + strlen(username), &message_length, 2);
        strcpy(mesg_msg + 8 + strlen(username), message);
        send(clientSocket, mesg_msg, sizeof(mesg_msg) - 1, 0);  // -1 exclude newline
    }

    // waiting for thread to finish and close socket
    pthread_join(receive_tid, NULL);
    close(clientSocket);
    pthread_exit(NULL);
}

int main(int argc, char **argv) {
    if (argc != 3) {
        printf("Usage: %s <server_ip> <server_port>\n", argv[0]);
        return 1;
    }

    char *serverIP = argv[1];
    int serverPort = atoi(argv[2]);

    // Make socket for client
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket < 0) {
        perror("Socket creation failed");
        return 1;
    }

    // Configure server address
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPort);
    if (inet_pton(AF_INET, serverIP, &serverAddr.sin_addr) <= 0) {
        perror("Invalid server address");
        return 1;
    }

    // Connect to server
    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Connection failed");
        return 1;
    }

    // thread to handle sending and receiving messages
    pthread_t tid;
    if (pthread_create(&tid, NULL, clientThread, &clientSocket) != 0) {
        perror("Thread creation failed");
        return 1;
    }

    // wait for client thread to close socket
    pthread_join(tid, NULL);
    close(clientSocket);

    return 0;
}
