
Repository to collect work done over the course of the CompOrg block

Intro 
Mention we're demonstrating we have knowledge of everything in the course. 

Language Fluency 
    C
            Memory Management 
                How memory works in C (malloc, pointers, and how to tell if a variable is in the stack or heap) 
            Leaks! What are they? What needs to be done to avoid them? 
        Functions and Controlflow 
            Like JAVA loops, if
            Kinda like JAVA functions and libraries
            Not like JAVA function name lookup; binary vs bytecode            
    ASM
