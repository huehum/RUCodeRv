#include <stdio.h>
#include <stdlib.h>

// Struct to represent the 2d map as opposed to the class from Map2.java
struct Map2 {
    char* data; // Pointer to a 1d array, stores map data
    int width; 
    int height;
};

// Initialize map with given witdth and height 
void initializeMap(struct Map2* map, int w, int h) {
    map->width = w;
    map->height = h;

    // Allocate memory, map data as 1d array
    map->data = (char*)malloc(w * h * sizeof(char));

    // Initialize each cell with #
    for (int i = 0; i < w * h; i++) {
        map->data[i] = '#';
    }
}

// Read map data from a file and populate map structure 
int readMap(struct Map2* map, const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        return 0; // Can't open file
    }

    int w, h;
    fscanf(file, "%d %d\n", &w, &h);
    if (w != map->width || h != map->height) {
        fclose(file);
        return 0; // Invalid map wnh
    }

    for (int i = 0; i < map->height; i++) {
        char line[map->width + 1]; 
        if (fscanf(file, "%s\n", line) != 1) {
            fclose(file);
            return 0; // Invalid file format
        }
        for (int j = 0; j < map->width; j++) {
            map->data[i * map->width + j] = line[j];
        }
    }

    fclose(file);
    return 1; 
}

// Show contents of map
void displayMap(struct Map2* map) {
    for (int i = 0; i < map->height; i++) {
        for (int j = 0; j < map->width; j++) {
            printf("%c", map->data[i * map->width + j]);
        }
        printf("\n"); // Move to next row
    }
}

void freeMap(struct Map2* map) {
    free(map->data);
}

int main() {
    struct Map2 m1, m2;

    // Initialize two different maps
    initializeMap(&m1, 15, 10);
    initializeMap(&m2, 20, 6);

    // Try to read map data from files
    if (!readMap(&m1, "map1.txt")) {
        printf("Bad map file! map1.txt\n");
        return 1;
    }

    if (!readMap(&m2, "map2.txt")) {
        printf("Bad map file! map2.txt\n");
        return 1;
    }

    // Show contents of both maps
    printf("---------- Map 1 ----------\n");
    displayMap(&m1);
    printf("---------- Map 2 ----------\n");
    displayMap(&m2);

    // Free memory for both maps
    freeMap(&m1);
    freeMap(&m2);

    return 0;
}
