#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Struct to represent a 2d point
struct Point {
    int x;
    int y;
};

// Struct function to create new points with x,y coordinates
struct Point* makepoint(int x, int y) {
    // Allocating memory for a new point in the heap
    struct Point* point = (struct Point*)malloc(sizeof(struct Point));

    // To check if memory allocation worked
    if (point != NULL) {
        point->x = x;
        point->y = y;
    }
    return point; // Returning a pointer to new point
}

// Convert point to a string 
char* pointToString(const struct Point* point) {
    // Allocate memory for the string
    char* str = (char*)malloc(20); //10 10 
    // Check if memory allocation worked
    if (str != NULL) {
        // Coordinates formatted into the string
        snprintf(str, 20, "(%d,%d)", point->x, point->y);
    }
    return str;
}


int getPointX(const struct Point* point) {
    return point->x;
}


int getPointY(const struct Point* point) {
    return point->y;
}

// Euclidean distance between two points
float getDistance(const struct Point* point1, const struct Point* point2) {
    int dx = getPointX(point1) - getPointX(point2);
    int dy = getPointY(point1) - getPointY(point2);
    // Pythagorean theorem to get distance
    return sqrt(dx * dx + dy * dy);
}

int main(int argc, char* argv[]) {
    // Checking for correct number of arguments
    if (argc != 5) {
        printf("Usage: ./point_demo x1 y1 x2 y2\n");
        return 1; //Error code 
    }

    // Parsing for the coordinates of the two points
    int x1 = atoi(argv[1]);
    int y1 = atoi(argv[2]);
    int x2 = atoi(argv[3]);
    int y2 = atoi(argv[4]);

    struct Point* p1 = makepoint(x1, y1);
    struct Point* p2 = makepoint(x2, y2);

    if (p1 == NULL || p2 == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Calculate and print the distance between the two points
    printf("Distance from %s to %s is %f\n", pointToString(p1), pointToString(p2), getDistance(p1, p2));

    // Freeing allocated memory for the points
    free(p1);
    free(p2);

    return 0;
}
