#include <stdio.h>
#include <stdlib.h>

// Defining struct to represent the map
struct Map1 {
    char** data;
    int width;
    int height;
};

// Initializes map with given width and height
void initializeMap(struct Map1* map, int w, int h) {
    map->width = w;
    map->height = h;

    // Allocate memory for our 2d array
    map->data = (char**)malloc(h * sizeof(char*));

    // Initialize cells with #'s 
    for (int i = 0; i < h; i++) {
        map->data[i] = (char*)malloc(w * sizeof(char));
        for (int j = 0; j < w; j++) {
            map->data[i][j] = '#';
        }
    }
}

// Read data from a file and populate the map struct
int readMap(struct Map1* map, const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        return 0; // In case it can't open file
    }

    int w, h;
    fscanf(file, "%d %d\n", &w, &h);
    if (w != map->width || h != map->height) {
        fclose(file);
        return 0; // In case of invalid map dimensions
    }

    for (int i = 0; i < map->height; i++) {
        for (int j = 0; j < map->width; j++) {
            int c = fgetc(file);
            if (c == EOF || c == '\n') {
                fclose(file);
                return 0;  // In case of invalid file format
            }
            map->data[i][j] = (char)c;
        }
        fgetc(file); // Read and discard newline character
    }

    fclose(file);
    return 1; // Reading map from file works
}

// Show contents of map
void displayMap(struct Map1* map) {
    for (int i = 0; i < map->height; i++) {
        for (int j = 0; j < map->width; j++) {
            printf("%c", map->data[i][j]); // Print cells
        }
        printf("\n"); // Move to next row
    }
}

// Free memory allocated for map
void freeMap(struct Map1* map) {
    for (int i = 0; i < map->height; i++) {
        free(map->data[i]); // For each row
    }
    free(map->data); // For the 2d array
}

int main() {
    struct Map1 m1, m2;

    // Initialize two maps, different dimensions
    initializeMap(&m1, 15, 10);
    initializeMap(&m2, 20, 6);

    // Read map data from file
    if (!readMap(&m1, "map1.txt")) {
        printf("Bad map file! map1.txt\n");
        return 1;
    }

    if (!readMap(&m2, "map2.txt")) {
        printf("Bad map file! map2.txt\n");
        return 1;
    }

    // Display contents of both maps
    printf("---------- Map 1 ----------\n");
    displayMap(&m1);
    printf("---------- Map 2 ----------\n");
    displayMap(&m2);

    // Freeing memory allocated for both maps
    freeMap(&m1);
    freeMap(&m2);

    return 0;
}
